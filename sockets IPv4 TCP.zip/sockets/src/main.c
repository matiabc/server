#include <stdio.h>

int main (int argc, char const *argv[]){
	printf("Hola desde IPv4 por TCP\n");
	return 0;
}
